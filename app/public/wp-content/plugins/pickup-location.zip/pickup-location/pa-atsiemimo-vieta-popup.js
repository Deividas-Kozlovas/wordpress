jQuery(document).ready(function($) {
    // Define locations grouped by cities
    var locations = {
        "Kaunas": [
            'Baltų pr. 18, Šilas, Kaunas',
            'Baranausko g. 26, Šilas, Kaunas',
            'Europos pr. 122, Cechas, Kaunas',
            'Savanorių pr. 116, Šilas, Kaunas',
            'Svirbygalos g. 2, Cechas, Kaunas'
        ],
        "Vilnius": [
            'Naugarduko g. 70, Kepyklėlė, Vilnius',
            'Verkių g. 31A, Ogmios miestas, Vilnius'
        ],
        "Palanga": [
            'Vytauto g. 98, Palanga'
        ]
    };

    function displayPopup() {
        var popupContent = '<div class="custom-popup-overlay"><div class="custom-popup-content">';
        popupContent += '<p>Pristatymą į namus galite užsisakyti per mūsų partnerius BOLT, WOLT ir LASTMILE arba užsisakius produkciją atsiimti mūsų kepyklėlėse:</p>';
        popupContent += '<p><strong>Pasirinkite artimiausią kepyklėlę:</strong></p>'; 

        $.each(locations, function(city, cityLocations) {
            popupContent += '<h3>' + city + '</h3><table>';
            $.each(cityLocations, function(index, location) {
                popupContent += '<tr><td><button class="custom-popup-button">' + location + '</button></td></tr>';
            });
            popupContent += '</table>';
        });

        popupContent += '</div></div>';
        $('body').append(popupContent);
        $('body').addClass('custom-blur-background no-scroll');

        // Re-bind the click event to ensure it works for dynamically created buttons
        $('.custom-popup-button').off('click').on('click', function() {
            var selectedLocation = $(this).text();

            // Fetch and save current cart items before clearing the cart
            $.ajax({
                url: '/wp-admin/admin-ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'get_cart_items'
                },
                success: function(response) {
                    if (response.success) {
                        var cartItems = response.data;
                        var previousLocation = localStorage.getItem('selectedLocation');
                        if (previousLocation) {
                            localStorage.setItem(previousLocation + '_cart', JSON.stringify(cartItems));
                        }
                        clearCartAndProceed(selectedLocation);
                    } else {
                        console.log('Failed to retrieve cart items.');
                    }
                },
                error: function(xhr, status, error) {
                    console.log('Error in AJAX request:', error);
                }
            });
        });
    }

    function clearCartAndProceed(selectedLocation) {
        // Clear WooCommerce cart via AJAX
        $.ajax({
            url: '/wp-admin/admin-ajax.php',
            type: 'POST',
            dataType: 'json',
            data: {
                action: 'clear_cart'
            },
            success: function(response) {
                if (response.success) {
                    console.log('Cart cleared successfully.');
                    localStorage.setItem('selectedLocation', selectedLocation);
                    localStorage.setItem('locationTimestamp', new Date().getTime());
                    $('.custom-popup-overlay').fadeOut(function() {
                        $(this).remove();
                        $('body').removeClass('custom-blur-background no-scroll');
                    });
                    setSelectedLocation(selectedLocation);
                } else {
                    console.log('Failed to clear the cart.');
                }
            },
            error: function(xhr, status, error) {
                console.log('Error in AJAX request:', error);
            }
        });
    }

    function setSelectedLocation(location) {
        var selectElement = $('#pa_atsiemimo-vieta');
        selectElement.find('option').each(function() {
            if ($(this).text() === location) {
                $(this).prop('selected', true);
            }
        });
        selectElement.prop('disabled', true); // Lock the selection
    }

    function checkAndDisplayPopup() {
        var selectedLocation = localStorage.getItem('selectedLocation');
        var timestamp = localStorage.getItem('locationTimestamp');
        var currentTime = new Date().getTime();
        var hours24 = 24 * 60 * 60 * 1000;

        if (selectedLocation && timestamp && (currentTime - timestamp < hours24)) {
            setSelectedLocation(selectedLocation);
            $('#pa_atsiemimo-vieta').prop('disabled', true); // Ensure it remains locked if already set
        } else {
            localStorage.removeItem('selectedLocation');
            localStorage.removeItem('locationTimestamp');
            displayPopup();
        }
    }

    checkAndDisplayPopup();

    $('#menu-item-9432 a').on('click', function(event) {
        event.preventDefault();
        localStorage.removeItem('selectedLocation');
        localStorage.removeItem('locationTimestamp');
        $('#pa_atsiemimo-vieta').prop('disabled', false); // Allow re-selection when explicitly showing the popup again
        displayPopup();
    });
});
