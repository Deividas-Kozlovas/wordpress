// date-picker.js

jQuery(document).ready(function($) {
    $("#order_date").datepicker({
        dateFormat: "yy-mm-dd"
    });
});
